package com.GreenSolar.cl.GreenSolar.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.GreenSolar.cl.GreenSolar.model.Proveedor;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {
    
}