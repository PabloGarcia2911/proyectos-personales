package com.GreenSolar.cl.GreenSolar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenSolarApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenSolarApplication.class, args);
	}

}
