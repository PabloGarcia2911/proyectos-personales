package com.GreenSolar.cl.GreenSolar.auth;

import lombok.Data;

@Data
public class AuthRequest {
    private String username;
    private String password;
}
